<?php
/*
Plugin Name: Font Awesome Integration
Description: Integrates Font Awesome into your WordPress site for use throughout the site.
Version: 1.0
Author: Nxvermore
*/

function font_awesome_integration() {
    wp_enqueue_style( 'font-awesome', 'https://use.fontawesome.com/releases/v5.14.0/css/all.css' );
}
add_action( 'wp_enqueue_scripts', 'font_awesome_integration' );